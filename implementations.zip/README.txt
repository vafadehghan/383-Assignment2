To run and build these files follow these steps.
    1. Install Rust and Cargo
    2. Enter either the implementations (cd implementations) or samples (cd samples) directory  
    3. Run the command "cargo build"
    4. Run the command "cargo run"

Vafa Dehghan Saei
301379021
